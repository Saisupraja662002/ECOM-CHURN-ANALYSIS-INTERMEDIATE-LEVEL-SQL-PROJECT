USE ecomm;

describe customer_churn;

select * from customer_churn limit 1;

----Impute mean for the following columns, and round off to the nearest integer if
----required:

--Mean
set sql_safe_updates = 0;

set @mean_warehouseToHome = (select round(avg(WarehouseToHome)) from
customer_churn where WarehouseToHome is not null);

set @mean_HourSpendOnApp = (select round(avg(HourSpendOnApp)) from
customer_churn where HourSpendOnApp is not null);

set @mean_OrderAmountHikeFromlastYear = (select round(avg(OrderAmountHikeFromlastYear)) from
customer_churn where OrderAmountHikeFromlastYear is not null);

set @mean_DaySinceLastOrder = (select round(avg(DaySinceLastOrder)) from
customer_churn where DaySinceLastOrder is not null); 

update customer_churn
set WarehouseToHome = @mean_warehouseToHome
where WarehouseToHome is null;

update customer_churn
set HourSpendOnApp = @mean_HourSpendOnApp
where HourSpendOnApp is null;

update customer_churn
set OrderAmountHikeFromlastYear = @mean_OrderAmountHikeFromlastYear
where OrderAmountHikeFromlastYear is null;

update customer_churn
set DaySinceLastOrder = @mean_DaySinceLastOrder
where DaySinceLastOrder is null;

--Impute mode for the following columns

set @mode_tenure = (SELECT Tenure FROM customer_churn GROUP BY Tenure ORDER BY COUNT(*) DESC LIMIT 1);

set @mode_CouponUsed = (SELECT CouponUsed FROM customer_churn GROUP BY CouponUsed ORDER BY COUNT(*) DESC LIMIT 1);

set @mode_OrderCount = (SELECT OrderCount FROM customer_churn GROUP BY OrderCount
 ORDER BY COUNT(*) DESC LIMIT 1);

update customer_churn
set Tenure = @mode_tenure 
where Tenure is null;

update customer_churn
set CouponUsed = @mode_CouponUsed
where CouponUsed is null

update customer_churn
set OrderCount = @mode_OrderCount
where OrderCount is null;

--Check Null Values

select
sum(case when CustomerID is null then 1 else 0 end) as customer_id_null_count,
sum(case when Churn is null then 1 else 0 end) as Churn_null_count,
sum(case when Tenure is null then 1 else 0 end) as Tenure_null_count,
sum(case when PreferredLoginDevice is null then 1 else 0 end) as PreferredLoginDevice_null_count,
sum(case when CityTier is null then 1 else 0 end) as CityTier_null_count,
sum(case when WarehouseToHome is null then 1 else 0 end) as WarehouseToHome_null_count,
sum(case when PreferredPaymentMode is null then 1 else 0 end) as PreferredPaymentMode_null_count,
sum(case when Gender is null then 1 else 0 end) as Gender_null_count,
sum(case when HourSpendOnApp is null then 1 else 0 end) as HourSpendOnApp_null_count,
sum(case when NumberOfDeviceRegistered is null then 1 else 0 end) as NumberOfDeviceRegistered_null_count,
sum(case when PreferedOrderCat is null then 1 else 0 end) as PreferedOrderCat_null_count,
sum(case when SatisfactionScore is null then 1 else 0 end) as SatisfactionScore_null_count,
sum(case when MaritalStatus is null then 1 else 0 end) as MaritalStatus_null_count,
sum(case when NumberOfAddress is null then 1 else 0 end) as NumberOfAddress_null_count,
sum(case when Complain is null then 1 else 0 end) as Complain_null_count,
sum(case when OrderAmountHikeFromlastYear is null then 1 else 0 end) as OrderAmountHikeFromlastYear_null_count,
sum(case when CouponUsed is null then 1 else 0 end) as CouponUsed_null_count,
sum(case when OrderCount is null then 1 else 0 end) as OrderCount_null_count,
sum(case when DaySinceLastOrder is null then 1 else 0 end) as DaySinceLastOrder_null_count,
sum(case when CashbackAmount is null then 1 else 0 end) as CashbackAmount_null_count
from customer_churn;

----Handle outliers in the 'WarehouseToHome' column by deleting rows where the
----values are greater than 100.

delete from customer_churn where WarehouseToHome > 100;


----Replace occurrences of “Phone” in the 'PreferredLoginDevice' column and
----“Mobile” in the 'PreferedOrderCat' column with “Mobile Phone” to ensure uniformity.

UPDATE customer_churn
SET PreferredLoginDevice = IF(PreferredLoginDevice='Phone', 'Mobile Phone', PreferredLoginDevice);

UPDATE customer_churn
SET PreferedOrderCat = IF(PreferedOrderCat='Mobile', 'Mobile Phone', PreferedOrderCat);

UPDATE customer_churn
SET PreferredPaymentMode = IF(PreferredPaymentMode='COD', 'Cash On Delivery',PreferredPaymentMode);

UPDATE customer_churn
SET PreferredPaymentMode = IF(PreferredPaymentMode='CC', 'Credit Card',PreferredPaymentMode);

UPDATE customer_churn
SET PreferredPaymentMode =
case when PreferredPaymentMode ='Credit Card' Then 'CC'
 else PreferredPaymentMode 
 end;

UPDATE customer_churn
SET PreferredPaymentMode = 'CC'
where PreferredPaymentMode = 'Credit Card';

alter table customer_churn
rename column PreferedOrderCat to PreferredOrderCat;

alter table customer_churn
rename column HourSpendOnApp to HoursSpentOnApp;


----Creating New Columns:
Create a new column named ‘ComplaintReceived’

alter table customer_churn
add column ComplaintReceived Bool;

ALTER TABLE customer_churn
MODIFY COLUMN ComplaintReceived VARCHAR(10);


update customer_churn
set ComplaintReceived =
case when Complain = 1 then 'yes'
else 'No'
end;

alter table customer_churn
add column ChurnStatus varchar(20);

update customer_churn
set ChurnStatus =
case when Churn = 1 then 'Churned'
else 'Active'
end;

alter table customer_churn
drop column Complain;

alter table customer_churn
drop column Churn;

--Data Exploration and Analysis

 ---Retrieve the count of churned and active customers from the dataset.

select count( ChurnStatus) as chruned_count 
from  customer_churn 
where ChurnStatus = 'Churned';

select count( ChurnStatus) as Active_count 
from  customer_churn 
where ChurnStatus = 'Active';

---Display the average tenure and total cashback amount of customers who churned.
select Round(avg(Tenure)) as Avg_Tenure, Sum(CashbackAmount) as Total_cashback
from  customer_churn 
where ChurnStatus = 'Churned';

---Determine the percentage of churned customers who complained.

select (Churned_complained/Total_churned)*100 as Percentage_of_Churned_Customers 
from
(select sum(case when ChurnStatus ='Churned' then 1 else 0 end) as Total_churned,
sum(case when ChurnStatus ='Churned' and ComplaintReceived = 'Yes' then 1 else 0 end ) 
as Churned_complained from customer_churn ) as t;


--Identify the city tier with the highest number of churned customers whose
---preferred order category is Laptop & Accessory.

select CityTier, sum(case when ChurnStatus ='Churned' and  PreferredOrderCat = 'Laptop & Accessory' then 1 else 0 end)
 as Highest_no_of_churned_customers 
from customer_churn group by CityTier ;


---Identify the most preferred payment mode among active customers.

select PreferredPaymentMode, sum(case when ChurnStatus ='Active' then 1 else 0 end)
 as Active_Customers_Most_Preferred_Payment_Mode
from customer_churn group by PreferredPaymentMode;

--Calculate the total order amount hike from last year for customers who are single
---and prefer mobile phones for ordering.

select sum(orderAmountHikeFromlastYear) as  total_order_amount_hike_from_last_year 
from customer_churn 
where MaritalStatus = 'Single' and PreferredOrderCat = 'Mobile Phone';

---Find the average number of devices registered among customers who used UPI as
---their preferred payment mode.
select avg(NumberOfDeviceRegistered) as avg_no_of_reg_device
from customer_churn where PreferredPaymentMode = 'UPI';

--Determine the city tier with the highest number of customers
select CityTier, count(customerID) as highest_number_of_customers
from customer_churn group by CityTier ;

-- Identify the gender that utilized the highest number of coupons.
select Gender,Count(Gender) as Utilized_coupons from customer_churn where CouponUsed = 1
group by Gender ;

--List the number of customers and the maximum hours spent on the app in each
--preferred order category.

select PreferredOrderCat,Count(CustomerID) as No_of_Customers, max(HoursSpentOnApp) as Max_hours_spent
from customer_churn group by PreferredOrderCat;

---Calculate the total order count for customers who prefer using credit cards and
---have the maximum satisfaction score.

select sum(OrderCount) as total_order_count , max(SatisfactionScore) as max_satisfaction_score
from customer_churn where PreferredPaymentMode = 'Credit Card';

---What is the average satisfaction score of customers who have complained?
select avg(SatisfactionScore) as avg_satisfaction_score from customer_churn
where ComplaintReceived = 'yes';

-- List the preferred order category among customers who used more than 5 coupons.
select PreferredOrdercat,Count(PreferredOrdercat) from customer_churn 
where Couponused > 5 group by PreferredOrdercat;

-- List the top 3 preferred order categories with the highest average cashback amount.
select  PreferredOrdercat, avg(CashbackAmount) as avg_cashback_amount from customer_churn 
group by PreferredOrdercat order by avg_cashback_amount desc limit 3  ;

--Find the preferred payment modes of customers whose average tenure is 10
----months and have placed more than 500 orders.

select PreferredPaymentMode,avg(Tenure) as avg_tenure,sum(OrderCount) as Ttl_Order_Cnt 
 from customer_churn 
group by PreferredPaymentMode
having avg_tenure > 10 and Ttl_Order_Cnt > 500;

---Categorize customers based on their distance from the warehouse to home such
---as 'Very Close Distance' for distances <=5km, 'Close Distance' for <=10km,
---'Moderate Distance' for <=15km, and 'Far Distance' for >15km. Then, display the
---churn status breakdown for each distance category.

select ChurnStatus,
 case when WarehouseToHome <=5 then 'Very Close Distance'
      when WarehouseToHome <=10 then 'Close Distance' 
	  when WarehouseToHome <=15 then 'Moderate Distance' 
else 'Far Distance' end as Distance_Category,
COUNT(*) AS Total_Customers
FROM customer_churn
GROUP BY 
    ChurnStatus,
    Distance_Category;
    
    
---List the customer’s order details who are married, live in City Tier-1, and their
---order counts are more than the average number of orders placed by all
---customers.

with avg_order as (
select avg(OrderCount) as avg_order_count
 from customer_churn
 ) 
 select sum(OrderCount) as Total_order,MaritalStatus,CityTier
 from customer_churn
 where CityTier = 1 and MaritalStatus = 'Married'
 Group by MaritalStatus,CityTier
 having  Total_order > (select  avg_order_count from avg_order) ;
 
 
 ---Display the return details along with the customer details of those who have
---churned and have made complaints.

select cr.return_id,cr.CustomerID,cr.ReturnDate,cr.RefundAmount,cc.ChurnStatus,cc.ComplaintReceived 
from customer_returns cr
inner join customer_churn cc
on cr.CustomerID = cc.CustomerID
where cc.ChurnStatus = 'Churned'
and cc.ComplaintReceived = 'Yes';